import React from 'react'

const JobsDashboard = () => {
  return (
    <div>
        <h3 className='ml-2'> THis is jobs dashboard to view jobs posted by Recruiter </h3>
    </div>
  )
}

export default JobsDashboard
